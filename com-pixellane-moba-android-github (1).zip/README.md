# Pixel Lane MOBA — Offline Android APK

Self-contained Android WebView wrapper bundling the HTML5 game as a local asset so it runs **100% offline** with persistent `localStorage`, hardware-accelerated Canvas 2D rendering, and GitHub Actions CI APK builds.

## Project Configuration

- **App Name:** Pixel Lane MOBA
- **Package ID:** `com.pixellane.moba`
- **Version:** `1.0.0` (`1`)
- **Orientation:** `sensorLandscape`
- **Asset Loader:** `WebViewAssetLoader` (`https://appassets.androidplatform.net/assets/www/index.html`)
- **Strict Offline Mode:** Enabled (`INTERNET` permission omitted)

## Build APK Automatically on GitHub

1. Create a new repository on GitHub (e.g. `username/pixel-lane-moba-apk`).
2. Extract this ZIP and push the project folder to `main`:
   ```bash
   git init
   git add .
   git commit -m "Initial offline Android APK setup"
   git branch -M main
   git remote add origin https://github.com/username/pixel-lane-moba-apk.git
   git push -u origin main
   ```
3. Open your repository on GitHub and click **Actions → Build Offline Android APK**.
4. Wait ~2–4 minutes for the workflow to finish, then download the **`moba-debug-apk`** artifact from the bottom of the workflow run summary.
5. Unzip the downloaded artifact and install `app-debug.apk` on your Android device (enable *Install unknown apps* if prompted).
