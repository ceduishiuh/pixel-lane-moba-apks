# Keep WebView JavaScript interfaces if added in future updates
-keepattributes *Annotation*
