# Pixel Lane MOBA — Offline Android APK

This repository packages the self-contained HTML5 game into a native Android WebView application (`com.pixellane.moba`) and builds an installable `.apk` automatically via GitHub Actions.

## Build Settings
- **App Name:** Pixel Lane MOBA
- **Application ID:** `com.pixellane.moba`
- **Version:** `1.0.0` (code `1`)
- **Orientation:** `sensorLandscape`
- **Network Mode:** 100% Offline (INTERNET permission omitted)
- **SDK Targets:** `minSdk 24` / `targetSdk 34`

## Two Ways to Build on GitHub

### Option A (Mobile Browser / 2 Files Only)
1. Upload your HTML game file directly to the root of this repository (for example `index.html`).
2. Open the **Actions** tab, click **set up a workflow yourself**, paste `.github/workflows/build-apk.yml`, and commit.
3. Wait ~1–2 minutes for **Build Offline Android APK** to finish and download **`pixel-lane-moba-debug-apk`** from **Artifacts**.

### Option B (Desktop / Git CLI Full Project)
```bash
git init
git add .
git commit -m "Initial offline Android APK setup"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/pixel-lane-moba.git
git push -u origin main
```
